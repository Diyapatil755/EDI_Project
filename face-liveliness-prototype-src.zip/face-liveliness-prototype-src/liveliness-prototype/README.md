# Face Liveliness Prototype

A browser-based reference implementation of the **face liveliness layer**
(Layer 3) from the EDI attendance system architecture. Combines a
**randomized active challenge** (blink / smile / turn head) with a
**passive texture/reflection heuristic** as a second signal, mirroring how
production liveliness systems layer active + passive checks.

## Running it

No build step — it's plain ES modules loaded directly in the browser.

```bash
# from this directory
python3 -m http.server 8000
# then open http://localhost:8000
```

Serving over `file://` will not work — ES module imports require a real
HTTP origin (browser CORS restriction). Camera access also requires either
`localhost` or HTTPS.

## Project structure

```
index.html               entry point, loads MediaPipe from CDN + main.js
css/styles.css            all styling
js/
  config.js                tunable thresholds, landmark indices, timing
  geometry.js               pure math: EAR, mouth ratio, yaw offset, bbox
  passiveAnalysis.js        passive texture/reflection heuristic (see note below)
  faceTracker.js            MediaPipe Face Mesh + Camera wrapper
  challengeController.js    the core state machine (calibrate -> challenge -> score)
  ui.js                     DOM bindings, kept separate from detection logic
  main.js                   wires everything together
```

**Why it's split this way:** `challengeController.js` and `geometry.js`
have no DOM dependencies beyond the one call into `passiveAnalysis.js` (which
needs the video element for pixel sampling). That's intentional — it's the
piece most likely to get ported into a native mobile app later, so it's kept
decoupled from `ui.js` and `main.js`.

## How the liveliness check works

1. **Calibration (~1.2s):** captures a neutral-face baseline for mouth width
   and head yaw, since these vary per-person and per-camera-angle.
2. **Randomized active challenge:** one of `blink`, `smile`, `turn_left`,
   `turn_right` is picked at random and the user has ~7s to perform it.
   Detection is landmark-geometry based (see `geometry.js`) — no ML model
   needed for this part.
3. **Passive scoring (runs concurrently):** while the active challenge plays
   out, frames are sampled and scored for spoof-likelihood based on texture
   and reflection statistics (see `passiveAnalysis.js`).
4. **Combined decision:**
   - Active fails (timeout / face lost) → **fail**, no passive check needed.
   - Active passes + passive risk low → **pass**.
   - Active passes + passive risk high → **flagged for admin review** (this
     maps to the "Admin Manual Review" branch in the architecture diagram —
     it's a deliberate soft-fail, not an auto-reject).

## ⚠️ Important: the passive signal is a heuristic, not a trained model

`js/passiveAnalysis.js` computes hand-engineered statistics (specular
highlight ratio, texture uniformity, color diversity) as a stand-in for a
real lightweight anti-spoofing CNN. This was a deliberate choice to keep the
prototype dependency-free and buildable without hosting model weights — it
is **not validated against any labeled dataset** and should not be treated
as production-ready spoof detection.

See the comment block at the bottom of `passiveAnalysis.js` for concrete
steps to swap it for a real model (Silent-Face-Anti-Spoofing, a fine-tuned
MobileNet, etc.) via TensorFlow.js or ONNX Runtime Web. The function
signature is designed to make that swap a drop-in replacement.

## Known limitations / open work for the team

- **Head-turn detection** is a 2D landmark-offset approximation, not a real
  3D pose solve. It works but is coarser than a proper yaw/pitch/roll
  estimate — fine for a prototype, worth revisiting for production.
- **All thresholds in `config.js` are starting points**, not tuned values —
  test against real users and realistic spoof attempts (printed photos,
  phone/tablet screen replays) before trusting them.
- **No liveliness-result logging/persistence yet** — `challengeController.js`
  emits a result via `onComplete(result, detail)`; wiring that into the
  blockchain ledger write is the next integration point.
- **Mobile:** this is a web prototype. For the actual app, MediaPipe has
  native Android/iOS SDKs — the detection *logic* in `geometry.js` and
  `challengeController.js` ports over conceptually, but the platform APIs
  (camera capture, ML inference) will need native equivalents.
